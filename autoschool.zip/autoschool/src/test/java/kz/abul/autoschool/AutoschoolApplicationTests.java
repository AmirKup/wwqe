package kz.abul.autoschool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoschoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
