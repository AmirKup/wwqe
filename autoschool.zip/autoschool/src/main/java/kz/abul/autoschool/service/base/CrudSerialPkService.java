package kz.abul.autoschool.service.base;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface CrudSerialPkService<T, ID> {

    Page<T> findAll(Pageable pageable);

    List<T> findAll();

    T findById(ID id);

    T editById(ID id, T edited);

    void deleteById(ID id);

    T create(T t);
}
