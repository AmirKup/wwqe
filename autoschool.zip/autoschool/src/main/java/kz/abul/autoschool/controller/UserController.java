package kz.abul.autoschool.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import kz.abul.autoschool.data.entity.user.User;
import kz.abul.autoschool.service.UserService;
import kz.abul.autoschool.validation.CreateValidation;
import kz.abul.autoschool.validation.EditValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/users")
public class UserController implements BaseTemplatePath {

    @Autowired
    private UserService userService;

    @GetMapping("/{id}")
    @PreAuthorize("#id == authentication.principal.user.id")
    public String getPageOfEdit(@PathVariable Integer id, Model model) {
        model.addAttribute("user", userService.findById(id));
        return withBaseTemplatePath("edit");
    }

    @PutMapping("/{id}")
    @PreAuthorize("#id == authentication.principal.user.id")
    public String performEdit(@PathVariable Integer id,
                              @ModelAttribute("user") @Validated(EditValidation.class) User user,
                              BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return withBaseTemplatePath("edit");
        }

        userService.editById(id, user);
        return withBaseTemplatePath("edit");
    }

    @PostMapping
    @PreAuthorize("isAnonymous()")
    public String performCreate(@ModelAttribute("user") @Validated(CreateValidation.class) User user,
                                BindingResult bindingResult, HttpServletRequest request, Model model) {
        if (bindingResult.hasErrors()) {
            return "/signup";
        }

        String passwordBeforeHashing = user.getPassword();
        userService.create(user);
        authWithHttpServletRequest(user.getEmail(), passwordBeforeHashing, request);
        return "redirect:/";
    }

    public void authWithHttpServletRequest(String username, String password, HttpServletRequest request) {
        try {
            request.login(username, password);
        } catch (ServletException e) {
            //LOGGER.error("Error while login ", e);
        }
    }

    @Override
    public String withBaseTemplatePath(String nameOrPath) {
        return "user/" + nameOrPath;
    }
}
