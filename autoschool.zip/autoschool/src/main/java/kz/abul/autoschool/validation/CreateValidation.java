package kz.abul.autoschool.validation;

import jakarta.validation.groups.Default;

public interface CreateValidation extends Default {
}
