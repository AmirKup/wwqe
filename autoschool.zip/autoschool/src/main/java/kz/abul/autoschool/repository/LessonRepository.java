package kz.abul.autoschool.repository;

import kz.abul.autoschool.data.entity.study.Lesson;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LessonRepository extends JpaRepository<Lesson, Integer> {

    List<Lesson> findAllByOrderByIdAsc();
}
