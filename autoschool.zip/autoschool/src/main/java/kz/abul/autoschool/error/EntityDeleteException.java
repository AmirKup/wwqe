package kz.abul.autoschool.error;

import org.springframework.validation.ObjectError;

public class EntityDeleteException extends DisplayedErrorException {
    public EntityDeleteException(ObjectError objectError) {
        super(objectError);
    }
}
