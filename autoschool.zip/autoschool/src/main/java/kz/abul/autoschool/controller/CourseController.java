package kz.abul.autoschool.controller;

import kz.abul.autoschool.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/courses")
public class CourseController implements BaseTemplatePath {

    @Autowired
    private CourseService courseService;

    @GetMapping
    public String getPageOfIndex(Model model) {
        model.addAttribute("courses", courseService.findAllByEnabledTrueAndSortBySequenceCourses());
        return withBaseTemplatePath("index");
    }

    @GetMapping("/{id}")
    public String getPageOfCourse(@PathVariable Integer id, Model model) {
        model.addAttribute("course", courseService.findByIdAndEnabledTrueAndSortBySequenceModulesAndLessons(id));
        return withBaseTemplatePath("course");
    }

    @GetMapping("/{id}/{moduleId}/{lessonId}")
    public String getPageOfLesson(@PathVariable Integer id, @PathVariable Integer moduleId, @PathVariable Integer lessonId, Model model) {
        model.addAttribute("lessonNavigator", courseService.constructLessonNavigator(id, moduleId, lessonId));
        return withBaseTemplatePath("lesson");
    }

    @Override
    public String withBaseTemplatePath(String nameOrPath) {
        return "course/" + nameOrPath;
    }
}