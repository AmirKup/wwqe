package kz.abul.autoschool.controller;

public interface BaseTemplatePath {

    String withBaseTemplatePath(String nameOrPath);
}
