package kz.abul.autoschool.service;

import kz.abul.autoschool.data.entity.study.Lesson;
import kz.abul.autoschool.data.entity.study.Module;
import kz.abul.autoschool.data.entity.study.mapping.ModuleLesson;
import kz.abul.autoschool.error.EntityDeleteException;
import kz.abul.autoschool.repository.LessonRepository;
import kz.abul.autoschool.repository.ModuleLessonRepository;
import kz.abul.autoschool.repository.ModuleRepository;
import kz.abul.autoschool.service.base.CrudSerialPkServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.ObjectError;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
public class LessonService extends CrudSerialPkServiceImpl<Lesson, Integer, LessonRepository> {

    private static final String objectName = "lesson";

    @Autowired
    private ModuleRepository moduleRepository;

    public List<Lesson> findAllAndSortByIdAsc() {
        return repository.findAllByOrderByIdAsc();
    }

    @Override
    public void deleteById(Integer id) {
        List<Module> modules = moduleRepository.findAll();
        List<Integer> moduleIds = new ArrayList<>();
        for (Module module : modules) {
            List<ModuleLesson> moduleLessons = module.getModuleLessons();
            for (ModuleLesson ml : moduleLessons) {
                if (ml.getLesson().getId().equals(id)) {
                    moduleIds.add(module.getId());
                }
            }
        }

        if (!moduleIds.isEmpty()) {
            throw new EntityDeleteException(new ObjectError(objectName, "Сначала отвяжите урок от модулей с ID: " + Arrays.toString(moduleIds.toArray())));
        }

        repository.deleteById(id);
    }
}
