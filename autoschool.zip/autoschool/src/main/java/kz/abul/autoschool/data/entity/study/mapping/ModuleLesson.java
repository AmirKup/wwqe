package kz.abul.autoschool.data.entity.study.mapping;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import kz.abul.autoschool.data.entity.base.AuditingEntity;
import kz.abul.autoschool.data.entity.base.CompositePkEntity;
import kz.abul.autoschool.data.entity.study.Lesson;
import kz.abul.autoschool.data.entity.study.mapping.key.ModuleLessonKey;
import kz.abul.autoschool.data.entity.study.Module;
import kz.abul.autoschool.validation.CreateValidation;
import kz.abul.autoschool.validation.EditValidation;
import kz.abul.autoschool.validation.SaveValidation;
import lombok.Getter;
import lombok.Setter;

@Entity
@IdClass(ModuleLessonKey.class)
@Table(name = "modules_lessons", uniqueConstraints = @UniqueConstraint(columnNames = {"module_id", "numberInSequence"}))
@Getter
@Setter
public class ModuleLesson extends AuditingEntity {

    @Id
    @ManyToOne(optional = false)
    @JoinColumn(name = "module_id", nullable = false)
    private Module module;

    @Id
    @ManyToOne(optional = false)
    @JoinColumn(name = "lesson_id", nullable = false)
    @NotNull(groups = {CreateValidation.class}, message = "Поле 'урок' не заполнено")
    private Lesson lesson;

    @NotNull(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле 'номер в последовательности' должно быть заполнено")
    @Min(value = 1, groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле 'номер в последовательности' должно быть не менее 1")
    private Integer numberInSequence;
}
