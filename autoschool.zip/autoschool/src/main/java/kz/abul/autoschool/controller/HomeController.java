package kz.abul.autoschool.controller;

import kz.abul.autoschool.data.entity.user.User;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class HomeController {

    @GetMapping
    public String getPageOfIndex(Model model) {
        return "index";
    }

    @GetMapping("/about")
    public String about() {
        return "about";
    }

    @GetMapping("/signin")
    @PreAuthorize("isAnonymous()")
    public String getPageOfSignin() {
        return "signin";
    }

    @GetMapping("/signup")
    @PreAuthorize("isAnonymous()")
    public String getPageOfSignup(@ModelAttribute User user) {
        return "signup";
    }
}
