package kz.abul.autoschool.error;

import org.springframework.validation.ObjectError;

public class EntityBoundException extends DisplayedErrorException {

    public EntityBoundException(ObjectError objectError) {
        super(objectError);
    }
}
