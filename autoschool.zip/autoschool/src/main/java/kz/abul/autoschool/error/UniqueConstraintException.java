package kz.abul.autoschool.error;

import org.springframework.validation.ObjectError;

public class UniqueConstraintException extends DisplayedErrorException {

    public UniqueConstraintException(ObjectError objectError) {
        super(objectError);
    }
}
