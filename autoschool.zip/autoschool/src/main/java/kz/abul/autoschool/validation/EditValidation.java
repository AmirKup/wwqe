package kz.abul.autoschool.validation;

import jakarta.validation.groups.Default;

public interface EditValidation extends Default {
}
