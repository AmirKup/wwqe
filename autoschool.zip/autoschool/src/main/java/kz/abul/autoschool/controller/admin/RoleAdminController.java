package kz.abul.autoschool.controller.admin;

import kz.abul.autoschool.controller.BaseTemplatePath;
import kz.abul.autoschool.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/roles")
public class RoleAdminController implements BaseTemplatePath {

    @Autowired
    private RoleService roleService;

    @GetMapping
    public String getPageOfIndex(Model model) {
        model.addAttribute("roles", roleService.findAll());
        return withBaseTemplatePath("index");
    }

    @Override
    public String withBaseTemplatePath(String nameOrPath) {
        return "admin/role/" + nameOrPath;
    }
}
