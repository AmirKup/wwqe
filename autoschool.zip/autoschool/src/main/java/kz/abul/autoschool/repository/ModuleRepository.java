package kz.abul.autoschool.repository;

import kz.abul.autoschool.data.entity.study.Module;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ModuleRepository extends JpaRepository<Module, Integer> {

    List<Module> findAllByOrderByIdAsc();
}
