package kz.abul.autoschool.data.entity.user;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import kz.abul.autoschool.data.entity.base.SerialPkEntity;
import kz.abul.autoschool.data.entity.user.User;
import kz.abul.autoschool.validation.CreateValidation;
import kz.abul.autoschool.validation.EditValidation;
import lombok.Getter;
import lombok.Setter;

import java.util.*;

@Entity
@Table(name = "roles", uniqueConstraints = @UniqueConstraint(columnNames = "name"))
@Getter
@Setter
public class Role extends SerialPkEntity<Integer> {

    @NotBlank
    private String name;

    @ManyToMany(mappedBy = "roles")
    private Set<User> users = new HashSet<>();
}
