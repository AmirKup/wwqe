package kz.abul.autoschool.controller.admin;

import kz.abul.autoschool.controller.BaseTemplatePath;
import kz.abul.autoschool.data.entity.study.Lesson;
import kz.abul.autoschool.data.entity.study.Module;
import kz.abul.autoschool.data.entity.study.mapping.ModuleLesson;
import kz.abul.autoschool.error.DisplayedErrorException;
import kz.abul.autoschool.error.EntityDeleteException;
import kz.abul.autoschool.service.LessonService;
import kz.abul.autoschool.validation.CreateValidation;
import kz.abul.autoschool.validation.EditValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/admin/lessons")
public class LessonAdminController implements BaseTemplatePath {

    @Autowired
    private LessonService lessonService;

    @GetMapping
    public String getPageOfIndex(Model model) {
        model.addAttribute("lessons", lessonService.findAllAndSortByIdAsc());
        return withBaseTemplatePath("index");
    }

    @GetMapping("/{id}")
    public String getPageOfEdit(@PathVariable Integer id, Model model) {
        model.addAttribute("lesson", lessonService.findById(id));
        return withBaseTemplatePath("edit");
    }

    @PutMapping("/{id}")
    public String performEdit(@PathVariable Integer id, @ModelAttribute @Validated(EditValidation.class) Lesson lesson, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return withBaseTemplatePath("edit");
        }
        lessonService.editById(id, lesson);
        return "redirect:/admin/lessons";
    }

    @DeleteMapping("/{id}")
    public String performDelete(@PathVariable Integer id, Model model) {
        try {
            lessonService.deleteById(id);
        } catch (EntityDeleteException e) {
            model.addAttribute("errorMessage", e.getObjectError().getDefaultMessage());
            return "error";
        }

        return "redirect:/admin/lessons";
    }

    @GetMapping("/create")
    public String getPageOfCreate(@ModelAttribute Lesson lesson) {
        return withBaseTemplatePath("create");
    }

    @PostMapping
    public String performCreate(@ModelAttribute @Validated(CreateValidation.class) Lesson lesson, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return withBaseTemplatePath("create");
        }
        lessonService.create(lesson);
        return "redirect:/admin/lessons";
    }

    @Override
    public String withBaseTemplatePath(String nameOrPath) {
        return "admin/lesson/" + nameOrPath;
    }
}
