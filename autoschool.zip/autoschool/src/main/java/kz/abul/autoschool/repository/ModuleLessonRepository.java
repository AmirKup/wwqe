package kz.abul.autoschool.repository;

import kz.abul.autoschool.data.entity.study.mapping.ModuleLesson;
import kz.abul.autoschool.data.entity.study.mapping.key.ModuleLessonKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ModuleLessonRepository extends JpaRepository<ModuleLesson, ModuleLessonKey> {

}
