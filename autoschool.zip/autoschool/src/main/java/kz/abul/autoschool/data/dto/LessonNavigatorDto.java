package kz.abul.autoschool.data.dto;

import kz.abul.autoschool.data.entity.study.Course;
import kz.abul.autoschool.data.entity.study.Lesson;
import kz.abul.autoschool.data.entity.study.Module;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LessonNavigatorDto {

    private Course course;
    private Module module;
    private Lesson lesson;
    private Lesson nextLesson;
    private Lesson previousLesson;
}
