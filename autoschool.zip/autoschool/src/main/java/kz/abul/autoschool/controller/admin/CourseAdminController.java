package kz.abul.autoschool.controller.admin;

import kz.abul.autoschool.controller.BaseTemplatePath;
import kz.abul.autoschool.data.entity.study.Course;
import kz.abul.autoschool.data.entity.study.mapping.CourseModule;
import kz.abul.autoschool.error.DisplayedErrorException;
import kz.abul.autoschool.repository.ModuleRepository;
import kz.abul.autoschool.service.CourseService;
import kz.abul.autoschool.service.ModuleService;
import kz.abul.autoschool.service.TransportCategoryService;
import kz.abul.autoschool.validation.CreateValidation;
import kz.abul.autoschool.validation.EditValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/courses")
public class CourseAdminController implements BaseTemplatePath {

    @Autowired
    private CourseService courseService;

    @Autowired
    private TransportCategoryService transportCategoryService;

    @Autowired
    private ModuleRepository moduleRepository;

    @Autowired
    private ModuleService moduleService;

    @GetMapping
    public String getPageOfIndex(Model model) {
        model.addAttribute("courses", courseService.findAllAndSortBySequenceCourses());
        return withBaseTemplatePath("index");
    }

    @GetMapping("/{id}")
    public String getPageOfEdit(@PathVariable Integer id, Model model) {
        model.addAttribute("course", courseService.findById(id));
        addAttributesForCreateTemplate(model);

        return withBaseTemplatePath("edit");
    }

    @PutMapping("/{id}")
    public String performEdit(@PathVariable Integer id, @ModelAttribute @Validated(EditValidation.class) Course course, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            addAttributesForCreateTemplate(model);
            return withBaseTemplatePath("edit");
        }

        try {
            courseService.editById(id, course);
        } catch (DisplayedErrorException e) {
            bindingResult.addError(e.getObjectError());
            addAttributesForCreateTemplate(model);
            return withBaseTemplatePath("edit");
        }

        return "redirect:/admin/courses";
    }

    @DeleteMapping("/{id}")
    public String performDelete(@PathVariable Integer id) {
        courseService.deleteById(id);
        return "redirect:/admin/courses";
    }

    @GetMapping("/create")
    public String getPageOfCreate(@ModelAttribute Course course, Model model) {
        addAttributesForCreateTemplate(model);
        return withBaseTemplatePath("create");
    }

    @PostMapping
    public String performCreate(@ModelAttribute @Validated(CreateValidation.class) Course course, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            addAttributesForCreateTemplate(model);
            return withBaseTemplatePath("create");
        }

        try {
            courseService.create(course);
        } catch (DisplayedErrorException e) {
            bindingResult.addError(e.getObjectError());
            addAttributesForCreateTemplate(model);
            return withBaseTemplatePath("create");
        }

        return "redirect:/admin/courses";
    }

    @GetMapping("/courses-modules")
    public String getPageOfModules(Model model) {
        model.addAttribute("courses", courseService.findAll());
        return withBaseTemplatePath("course-module");
    }

    @GetMapping("/{id}/add-module")
    public String getPageOfAddModule(@PathVariable Integer id, @ModelAttribute CourseModule courseModule, Model model) {
        addAttributesForAddModuleTemplate(id, model);
        return withBaseTemplatePath("add-module");
    }

    @PostMapping("/{id}/add-module")
    public String performAddModule(@PathVariable Integer id, @ModelAttribute @Validated(CreateValidation.class) CourseModule courseModule, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            addAttributesForAddModuleTemplate(id, model);
            return withBaseTemplatePath("add-module");
        }

        try {
            courseService.addModule(id, courseModule);
        } catch (DisplayedErrorException e) {
            bindingResult.addError(e.getObjectError());
            addAttributesForAddModuleTemplate(id, model);
            return withBaseTemplatePath("add-module");
        }

        return "redirect:/admin/courses/courses-modules";
    }


    @DeleteMapping("/{id}/remove-module")
    public String performRemoveModule(@PathVariable Integer id, @RequestParam Integer moduleId, Model model) {
        courseService.removeModule(id, moduleId);
        return "redirect:/admin/courses/courses-modules";
    }

    private void addAttributesForCreateTemplate(Model model) {
        model.addAttribute("transportCategories", transportCategoryService.findAll());
    }

    public void addAttributesForAddModuleTemplate(Integer courseId, Model model) {
        model.addAttribute("course", courseService.findById(courseId));
        model.addAttribute("modules", moduleService.findAll());
    }

    @Override
    public String withBaseTemplatePath(String nameOrPath) {
        return "admin/course/" + nameOrPath;
    }
}
