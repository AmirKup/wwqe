package kz.abul.autoschool.data.entity.study;

import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotBlank;
import kz.abul.autoschool.data.entity.base.SerialPkEntity;
import kz.abul.autoschool.validation.CreateValidation;
import kz.abul.autoschool.validation.EditValidation;
import kz.abul.autoschool.validation.SaveValidation;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "transport_categories", uniqueConstraints = @UniqueConstraint(columnNames = "name"))
@Getter
@Setter
public class TransportCategory extends SerialPkEntity<Integer> {

    @NotBlank(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Название\" не заполнено")
    private String name;
}
