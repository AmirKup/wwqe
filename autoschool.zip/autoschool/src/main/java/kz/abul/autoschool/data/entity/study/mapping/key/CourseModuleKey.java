package kz.abul.autoschool.data.entity.study.mapping.key;

import jakarta.persistence.*;
import kz.abul.autoschool.data.entity.study.Course;
import kz.abul.autoschool.data.entity.study.Module;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
public class CourseModuleKey implements Serializable {

    private Course course;
    private Module module;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CourseModuleKey that = (CourseModuleKey) o;
        return course.equals(that.course) && module.equals(that.module);
    }

    @Override
    public int hashCode() {
        return Objects.hash(course, module);
    }
}