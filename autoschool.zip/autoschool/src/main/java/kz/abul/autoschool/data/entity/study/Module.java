package kz.abul.autoschool.data.entity.study;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import kz.abul.autoschool.data.entity.base.SerialPkEntity;
import kz.abul.autoschool.data.entity.study.mapping.CourseModule;
import kz.abul.autoschool.data.entity.study.mapping.ModuleLesson;
import kz.abul.autoschool.validation.CreateValidation;
import kz.abul.autoschool.validation.EditValidation;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "modules")
@Getter
@Setter
public class Module extends SerialPkEntity<Integer> {

    @NotBlank(groups = {CreateValidation.class, EditValidation.class, CreateValidation.class}, message = "Поле 'Заголовок' не заполнено")
    private String title;

    @OneToMany(mappedBy = "module", cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.EAGER, orphanRemoval = true)
    private List<ModuleLesson> moduleLessons = new ArrayList<>();

    public void addModuleLesson(ModuleLesson moduleLesson) {
        moduleLessons.add(moduleLesson);
        moduleLesson.setModule(this);
    }

    public void removeModuleLesson(ModuleLesson moduleLesson) {
        moduleLessons.remove(moduleLesson);
        moduleLesson.setModule(null);
    }
}
