package kz.abul.autoschool.service;

import kz.abul.autoschool.data.entity.study.Course;
import kz.abul.autoschool.data.entity.study.TransportCategory;
import kz.abul.autoschool.data.entity.study.mapping.CourseModule;
import kz.abul.autoschool.error.EntityDeleteException;
import kz.abul.autoschool.error.UniqueConstraintException;
import kz.abul.autoschool.repository.TransportCategoryRepository;
import kz.abul.autoschool.service.base.CrudSerialPkServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.ObjectError;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class TransportCategoryService extends CrudSerialPkServiceImpl<TransportCategory, Integer, TransportCategoryRepository> {

    private final String objectName = "transportCategory";

    @Autowired
    private CourseService courseService;

    @Override
    public TransportCategory editById(Integer integer, TransportCategory edited) {
        if (repository.existsByName(edited.getName())) {
            throw new UniqueConstraintException(new ObjectError(objectName, "Указаное название категории уже существует"));
        }
        return super.editById(integer, edited);
    }

    @Override
    public TransportCategory create(TransportCategory transportCategory) {
        if (repository.existsByName(transportCategory.getName())) {
            throw new UniqueConstraintException(new ObjectError(objectName, "Указаное название категории уже существует"));
        }
        return super.create(transportCategory);
    }

    @Override
    public void deleteById(Integer integer) {
        List<Course> courses = courseService.findAll();
        List<Integer> courseIds = new ArrayList<>();
        for (Course course : courses) {
            if (course.getTransportCategory().getId().equals(integer)) {
                courseIds.add(course.getId());
            }
        }

        if (!courseIds.isEmpty()) {
            throw new EntityDeleteException(new ObjectError(objectName, "Сначала отвяжите категорию от курсов с ID: " + Arrays.toString(courseIds.toArray())));
        }

        repository.deleteById(integer);
    }
}