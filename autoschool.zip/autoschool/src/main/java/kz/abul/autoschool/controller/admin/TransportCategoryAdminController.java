package kz.abul.autoschool.controller.admin;

import kz.abul.autoschool.controller.BaseTemplatePath;
import kz.abul.autoschool.data.entity.study.TransportCategory;
import kz.abul.autoschool.error.DisplayedErrorException;
import kz.abul.autoschool.error.EntityDeleteException;
import kz.abul.autoschool.service.TransportCategoryService;
import kz.abul.autoschool.validation.CreateValidation;
import kz.abul.autoschool.validation.EditValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/transport-categories")
public class TransportCategoryAdminController implements BaseTemplatePath {

    @Autowired
    private TransportCategoryService transportCategoryService;

    @GetMapping
    public String getPageOfIndex(Model model) {
        model.addAttribute("transportCategories", transportCategoryService.findAll());
        return withBaseTemplatePath("index");
    }

    @GetMapping("/{id}")
    public String getPageOfEdit(@PathVariable Integer id, @ModelAttribute TransportCategory transportCategory, BindingResult bindingResult, Model model) {
        model.addAttribute("transportCategory", transportCategoryService.findById(id));
        return withBaseTemplatePath("edit");
    }

    @PutMapping("/{id}")
    public String performEdit(@PathVariable Integer id, @ModelAttribute @Validated(EditValidation.class) TransportCategory transportCategory, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return withBaseTemplatePath("edit");
        }

        try {
            transportCategoryService.editById(id, transportCategory);
        } catch (DisplayedErrorException e) {
            bindingResult.addError(e.getObjectError());
            return withBaseTemplatePath("edit");
        }

        return "redirect:/admin/transport-categories";
    }

    @DeleteMapping("/{id}")
    public String performDelete(@PathVariable Integer id, Model model) {
        try {
            transportCategoryService.deleteById(id);
        } catch (EntityDeleteException e) {
            model.addAttribute("errorMessage", e.getObjectError().getDefaultMessage());
            return "error";
        }

        return "redirect:/admin/transport-categories";
    }

    @GetMapping("/create")
    public String getPageOfCreate(@ModelAttribute TransportCategory transportCategory) {
        return withBaseTemplatePath("create");
    }

    @PostMapping
    public String performCreate(@ModelAttribute @Validated(CreateValidation.class) TransportCategory transportCategory, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return withBaseTemplatePath("create");
        }

        try {
            transportCategoryService.create(transportCategory);
        } catch (DisplayedErrorException e) {
            bindingResult.addError(e.getObjectError());
            return withBaseTemplatePath("create");
        }

        return "redirect:/admin/transport-categories";
    }

    @Override
    public String withBaseTemplatePath(String nameOrPath) {
        return "admin/transport-category/" + nameOrPath;
    }
}
