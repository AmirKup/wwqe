package kz.abul.autoschool.data.entity.study;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import kz.abul.autoschool.data.entity.base.SerialPkEntity;
import kz.abul.autoschool.data.entity.study.mapping.CourseModule;
import kz.abul.autoschool.data.entity.study.mapping.ModuleLesson;
import kz.abul.autoschool.validation.CreateValidation;
import kz.abul.autoschool.validation.EditValidation;
import kz.abul.autoschool.validation.SaveValidation;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "courses", uniqueConstraints = @UniqueConstraint(columnNames = "numberInSequence"))
@Getter
@Setter
public class Course extends SerialPkEntity<Integer> {

    @NotNull(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Категория транспорта\" не заполнено")
    @ManyToOne(optional = false)
    @JoinColumn(name = "transport_category_id", nullable = false)
    private TransportCategory transportCategory;

    @NotBlank(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Заголовок\" не заполнено")
    private String title;

    @NotBlank(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Описание\" не заполнено")
    private String description;

    @NotBlank(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Допускаются\" не заполнено")
    private String allowedTo;

    @NotBlank(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Категория тех.регламента\" не заполнено")
    private String categoryTechnicalRegulations;

    @NotNull(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Номер в последовательности\" не заполнено")
    @Min(value = 1, groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Номер в последовательности\" должно быть не меньше \"1\"")
    private Integer numberInSequence;

    @NotNull(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Действующий\" не заполнено")
    private Boolean enabled;

    @OneToMany(mappedBy = "course", cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.EAGER, orphanRemoval = true)
    private List<CourseModule> courseModules = new ArrayList<>();

    public void addCourseModule(CourseModule courseModule) {
        courseModules.add(courseModule);
        courseModule.setCourse(this);
    }

    public void removeCourseModule(CourseModule courseModule) {
        courseModules.remove(courseModule);
        courseModule.setCourse(null);
    }

    public int countModules() {
        return courseModules.size();
    }

    public int countLessons() {
        int total = 0;
        for (CourseModule courseModule : courseModules) {
            for (ModuleLesson moduleLesson : courseModule.getModule().getModuleLessons()) {
                total++;
            }
        }

        return total;
    }
}
