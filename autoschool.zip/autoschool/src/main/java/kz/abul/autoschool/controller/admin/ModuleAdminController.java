package kz.abul.autoschool.controller.admin;

import kz.abul.autoschool.controller.BaseTemplatePath;
import kz.abul.autoschool.data.entity.study.Module;
import kz.abul.autoschool.data.entity.study.mapping.ModuleLesson;
import kz.abul.autoschool.error.DisplayedErrorException;
import kz.abul.autoschool.error.EntityDeleteException;
import kz.abul.autoschool.service.LessonService;
import kz.abul.autoschool.service.ModuleService;
import kz.abul.autoschool.validation.CreateValidation;
import kz.abul.autoschool.validation.EditValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/modules")
public class ModuleAdminController implements BaseTemplatePath {

    @Autowired
    private ModuleService moduleService;

    @Autowired
    private LessonService lessonService;

    @GetMapping
    public String getPageOfIndex(Model model) {
        model.addAttribute("modules", moduleService.findAllAndSortById());
        return withBaseTemplatePath("index");
    }

    @GetMapping("/{id}")
    public String getPageOfEdit(@PathVariable Integer id, Model model) {
        model.addAttribute("module", moduleService.findById(id));
        return withBaseTemplatePath("edit");
    }

    @PutMapping("/{id}")
    public String performEdit(@PathVariable Integer id, @ModelAttribute @Validated(EditValidation.class) Module module, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return withBaseTemplatePath("edit");
        }

        moduleService.editById(id, module);
        return "redirect:/admin/modules";
    }

    @DeleteMapping("/{id}")
    public String performDelete(@PathVariable Integer id, Model model) {
        try {
            moduleService.deleteById(id);
        } catch (EntityDeleteException e) {
            model.addAttribute("errorMessage", e.getObjectError().getDefaultMessage());
            return "error";
        }

        return "redirect:/admin/modules";
    }

    @GetMapping("/create")
    public String getPageOfCreate(@ModelAttribute Module module, Model model) {
        return withBaseTemplatePath("create");
    }

    @PostMapping
    public String performCreate(@ModelAttribute @Validated(CreateValidation.class) Module module, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return withBaseTemplatePath("create");
        }
        moduleService.create(module);
        return "redirect:/admin/modules";
    }

    @GetMapping("/modules-lessons")
    public String getPageOfModules(Model model) {
        model.addAttribute("modules", moduleService.findAll());
        return withBaseTemplatePath("module-lesson");
    }

    @GetMapping("/{id}/add-lesson")
    public String getPageOfAddLesson(@PathVariable Integer id, @ModelAttribute ModuleLesson moduleLesson, Model model) {
        addAttributesForAddLessonTemplate(id, moduleLesson, model);
        return withBaseTemplatePath("add-lesson");
    }

    @PostMapping("/{id}/add-lesson")
    public String performAddLesson(@PathVariable Integer id, @ModelAttribute @Validated(CreateValidation.class) ModuleLesson moduleLesson, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            addAttributesForAddLessonTemplate(id, moduleLesson, model);
            return withBaseTemplatePath("add-lesson");
        }

        try {
            moduleService.addLesson(id, moduleLesson);
        } catch (DisplayedErrorException e) {
            bindingResult.addError(e.getObjectError());
            addAttributesForAddLessonTemplate(id, moduleLesson, model);
            return withBaseTemplatePath("add-lesson");
        }

        return "redirect:/admin/modules/modules-lessons";
    }

    @DeleteMapping("/{id}/remove-lesson")
    public String performRemoveLesson(@PathVariable Integer id, @RequestParam Integer lessonId, Model model) {
        moduleService.removeLesson(id, lessonId);
        return "redirect:/admin/modules/modules-lessons";
    }

    @Override
    public String withBaseTemplatePath(String nameOrPath) {
        return "admin/module/" + nameOrPath;
    }

    private void addAttributesForAddLessonTemplate(Integer moduleId, ModuleLesson moduleLesson, Model model) {
        model.addAttribute("module", moduleService.findById(moduleId));
        model.addAttribute("lessons", lessonService.findAllAndSortByIdAsc());
    }
}
