package kz.abul.autoschool.controller.admin;

import kz.abul.autoschool.controller.BaseTemplatePath;
import kz.abul.autoschool.service.RoleService;
import kz.abul.autoschool.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/users")
public class UserAdminController implements BaseTemplatePath {

    @Autowired
    private UserService userService;

    @Autowired
    private RoleService roleService;

    @GetMapping
    public String getPageOfIndex(Model model) {
        model.addAttribute("users", userService.findAllAndSortById());
        return withBaseTemplatePath("index");
    }

    @PutMapping("/{id}/locked")
    public String performLocked(@PathVariable Integer id, @RequestParam Boolean locked, Model model) {
        userService.locked(id, locked);
        return "redirect:/admin/users";
    }

    @GetMapping("/users-roles")
    public String getPageOfUsersRoles(Model model) {
        model.addAttribute("users", userService.findAll());
        return withBaseTemplatePath("user-role");
    }

    @GetMapping("/{id}/add-role")
    public String getPageOfAssignRole(@PathVariable Integer id, Model model) {
        model.addAttribute("user", userService.findById(id));
        model.addAttribute("roles", userService.findAllRolesWhichUserNotHave(id));
        return withBaseTemplatePath("add-role");
    }

    @PostMapping("/{id}/add-role")
    public String performAssignRole(@PathVariable Integer id, @RequestParam Integer roleId, Model model) {
        userService.addRole(id, roleId);
        return "redirect:/admin/users/users-roles";
    }

    @DeleteMapping("/{id}/remove-role")
    public String performDelete(@PathVariable Integer id, @RequestParam Integer roleId) {
        userService.removeRole(id, roleId);
        return "redirect:/admin/users/users-roles";
    }

    @Override
    public String withBaseTemplatePath(String nameOrPath) {
        return "admin/user/" + nameOrPath;
    }
}
