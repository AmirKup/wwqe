package kz.abul.autoschool.service;

import kz.abul.autoschool.data.entity.study.Course;
import kz.abul.autoschool.data.entity.study.Module;
import kz.abul.autoschool.data.entity.study.mapping.CourseModule;
import kz.abul.autoschool.data.entity.study.mapping.ModuleLesson;
import kz.abul.autoschool.error.EntityBoundException;
import kz.abul.autoschool.error.EntityDeleteException;
import kz.abul.autoschool.error.UniqueConstraintException;
import kz.abul.autoschool.repository.CourseRepository;
import kz.abul.autoschool.repository.ModuleRepository;
import kz.abul.autoschool.service.base.CrudSerialPkServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.ObjectError;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class ModuleService extends CrudSerialPkServiceImpl<Module, Integer, ModuleRepository> {

    private final String objectName = "module";

    @Autowired
    private CourseService courseService;

    public List<Module> findAllAndSortById() {
        return repository.findAllByOrderByIdAsc();
    }

    public void addLesson(Integer id, ModuleLesson moduleLesson) {
        Module module = findById(id);
        if (hasLesson(module, moduleLesson.getLesson().getId())) {
            throw new UniqueConstraintException(new ObjectError(objectName, "Урок уже был привязан ранее"));
        }
        if (hasNumberInSequenceByLessons(module, moduleLesson.getNumberInSequence())) {
            throw new UniqueConstraintException(new ObjectError(objectName, "Указаный номер в последовательности уже существует"));
        }

        module.addModuleLesson(moduleLesson);
        repository.save(module);
    }

    public void removeLesson(Integer id, Integer lessonId) {
        Module module = findById(id);
        if (!hasLesson(module, lessonId)) {
            throw new EntityBoundException(new ObjectError(objectName, "Указанный урок не привязан"));
        }

        List<ModuleLesson> moduleLessons = module.getModuleLessons();
        for (ModuleLesson moduleLesson : moduleLessons) {
            if (moduleLesson.getLesson().getId().equals(lessonId)) {
                module.removeModuleLesson(moduleLesson);
                repository.save(module);
                break;
            }
        }
    }

    private boolean hasLesson(Module module, Integer lessonId) {
        return module.getModuleLessons()
                .stream()
                .anyMatch(moduleLesson -> moduleLesson.getLesson().getId().equals(lessonId));
    }

    private boolean hasNumberInSequenceByLessons(Module module, Integer numberInSequence) {
        return module.getModuleLessons()
                .stream()
                .anyMatch(moduleLesson -> moduleLesson.getNumberInSequence().equals(numberInSequence));
    }

    @Override
    public Module editById(Integer integer, Module edited) {
        Module module = findById(integer);
        module.setTitle(edited.getTitle());
        return repository.save(module);
    }

    @Override
    public void deleteById(Integer id) {
        List<Course> courses = courseService.findAll();
        List<Integer> courseIds = new ArrayList<>();
        for (Course course : courses) {
            List<CourseModule> courseModules = course.getCourseModules();
            for (CourseModule cm : courseModules) {
                if (cm.getModule().getId().equals(id)) {
                    courseIds.add(course.getId());
                }
            }
        }

        if (!courseIds.isEmpty()) {
            throw new EntityDeleteException(new ObjectError(objectName, "Сначала отвяжите модуль от курсов с ID: " + Arrays.toString(courseIds.toArray())));
        }

        repository.deleteById(id);
    }
}
