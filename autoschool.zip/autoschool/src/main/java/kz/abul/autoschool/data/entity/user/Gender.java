package kz.abul.autoschool.data.entity.user;

public enum Gender {
    MALE, FEMALE
}
