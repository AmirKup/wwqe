package kz.abul.autoschool.service;

import kz.abul.autoschool.data.entity.user.Role;
import kz.abul.autoschool.repository.RoleRepository;
import kz.abul.autoschool.service.base.CrudSerialPkServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class RoleService extends CrudSerialPkServiceImpl<Role, Integer, RoleRepository> {


//    public void remove(Integer roleId, Integer userId) {
//        Role role = findById(roleId);
//        User user =
//        role.removeUser();
//    }
}
