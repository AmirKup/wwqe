package kz.abul.autoschool.listener;

import jakarta.persistence.PrePersist;
import jakarta.validation.*;
import kz.abul.autoschool.validation.SaveValidation;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

public class BaseListener {

    @Autowired
    private static final Validator validator;

    static {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
        factory.close();
    }

    @PrePersist
    private void beforeSave(Object obj) {
        Set<ConstraintViolation<Object>> violationSet = validator.validate(obj, SaveValidation.class);
        if (!violationSet.isEmpty()) {
            throw new ConstraintViolationException(violationSet);
        }
    }
}