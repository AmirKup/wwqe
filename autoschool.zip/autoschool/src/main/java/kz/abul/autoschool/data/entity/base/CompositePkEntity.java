package kz.abul.autoschool.data.entity.base;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@MappedSuperclass
@Getter
@Setter
public abstract class CompositePkEntity<ID extends Serializable> extends AuditingEntity {

    @EmbeddedId
    private ID id;
}
