package kz.abul.autoschool.service;

import jakarta.persistence.EntityNotFoundException;
import kz.abul.autoschool.data.entity.user.User;
import kz.abul.autoschool.data.entity.user.Role;
import kz.abul.autoschool.repository.UserRepository;
import kz.abul.autoschool.service.base.CrudSerialPkServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService extends CrudSerialPkServiceImpl<User, Integer, UserRepository> {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleService roleService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public List<User> findAllAndSortById() {
        return repository.findAllByOrderByIdAsc();
    }

    @Override
    public User editById(Integer id, User edited) {
        User user = userRepository.findById(id).orElseThrow(EntityNotFoundException::new);

        user.setName(edited.getName());
        user.setSurname(edited.getSurname());
        user.setPatronymic(edited.getPatronymic());
        user.setGender(edited.getGender());

        return repository.save(user);
    }

    @Override
    public User create(User user) {
        user.setLocked(false);
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return super.create(user);
    }

    public User findByEmail(String email) {
        return repository.findByEmail(email)
                .orElseThrow(EntityNotFoundException::new);
    }

    public List<Role> findAllRolesWhichUserNotHave(Integer id) {
        User user = findById(id);
        List<Role> roles = roleService.findAll();
        roles.removeAll(user.getRoles());

        return roles;
    }

    public void addRole(Integer userId, Integer roleId) {
        User user = this.findById(userId);
        Role role = roleService.findById(roleId);

        user.addRole(role);
        userRepository.save(user);
    }

    public void removeRole(Integer userId, Integer roleId) {
        User user = this.findById(userId);
        Role role = roleService.findById(roleId);

        user.removeRole(role);
        userRepository.save(user);
    }

    public void locked(Integer id, boolean locked) {
        User user = findById(id);
        user.setLocked(locked);
        repository.save(user);
    }

    public boolean passwordMatchesPattern(String password) {
        return password.matches("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z0-9@#$%^&+=_]{7,25}$");
    }
}
