package kz.abul.autoschool.repository;

import kz.abul.autoschool.data.entity.study.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CourseRepository extends JpaRepository<Course, Integer> {

    Optional<Course> findByIdAndEnabledTrue(int id);
    List<Course> findAllByEnabledTrueOrderByNumberInSequenceAsc();
    List<Course> findAllByOrderByNumberInSequenceAsc();
    boolean existsByNumberInSequence(int numberInSequence);
}
