package kz.abul.autoschool.error;

import lombok.Getter;
import org.springframework.validation.ObjectError;

@Getter
public class DisplayedErrorException extends RuntimeException {

    private final ObjectError objectError;

    public DisplayedErrorException(ObjectError objectError) {
        this.objectError = objectError;
    }
}
