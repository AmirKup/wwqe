package kz.abul.autoschool.repository;

import kz.abul.autoschool.data.entity.study.TransportCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransportCategoryRepository extends JpaRepository<TransportCategory, Integer> {

    boolean existsByName(String name);
}