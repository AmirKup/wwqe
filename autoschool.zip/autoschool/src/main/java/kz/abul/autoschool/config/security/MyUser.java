package kz.abul.autoschool.config.security;

import kz.abul.autoschool.data.entity.user.User;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

public class MyUser extends org.springframework.security.core.userdetails.User {
    private final User user;

    public MyUser(String username, String password, boolean enabled, boolean accountNonExpired, boolean credentialsNonExpired, boolean accountNonLocked, Collection<? extends GrantedAuthority> authorities, User user) {
        super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
        this.user = user;
    }

    public User getUser() {
        return user;
    }
}
