package kz.abul.autoschool.data.entity.study.mapping.key;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import kz.abul.autoschool.data.entity.study.Lesson;
import kz.abul.autoschool.data.entity.study.Module;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
public class ModuleLessonKey implements Serializable {

    private Module module;
    private Lesson lesson;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ModuleLessonKey that = (ModuleLessonKey) o;
        return module.equals(that.module) && lesson.equals(that.lesson);
    }

    @Override
    public int hashCode() {
        return Objects.hash(module, lesson);
    }
}
