package kz.abul.autoschool.data.entity.study;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import kz.abul.autoschool.data.entity.base.SerialPkEntity;
import kz.abul.autoschool.validation.CreateValidation;
import kz.abul.autoschool.validation.EditValidation;
import kz.abul.autoschool.validation.SaveValidation;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "lessons")
@Getter
@Setter
public class Lesson extends SerialPkEntity<Integer> {

    @NotBlank(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Заголовок\" не заполнено")
    private String title;

    @NotBlank(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Контент\" не заполнено")
    @Size(max = 1000000, groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"контент\" содержит более 1000000 символов")
    @Column(length = 1000000)
    private String contentHtml;

    @NotNull(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Минут для чтения\" не заполнено")
    @Min(value = 1, groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Минут для чтения\" должно быть не меньше 1")
    private Integer minutesToRead;
}
