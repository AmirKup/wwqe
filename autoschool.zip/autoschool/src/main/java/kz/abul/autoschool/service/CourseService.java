package kz.abul.autoschool.service;

import jakarta.persistence.EntityNotFoundException;
import kz.abul.autoschool.data.dto.LessonNavigatorDto;
import kz.abul.autoschool.data.entity.study.Course;
import kz.abul.autoschool.data.entity.study.Lesson;
import kz.abul.autoschool.data.entity.study.mapping.CourseModule;
import kz.abul.autoschool.data.entity.study.mapping.ModuleLesson;
import kz.abul.autoschool.data.entity.study.Module;
import kz.abul.autoschool.error.EntityBoundException;
import kz.abul.autoschool.error.UniqueConstraintException;
import kz.abul.autoschool.repository.CourseRepository;
import kz.abul.autoschool.service.base.CrudSerialPkServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.validation.ObjectError;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Service
public class CourseService extends CrudSerialPkServiceImpl<Course, Integer, CourseRepository> {

    private final String objectName = "course";

    public List<Course> findAllByEnabledTrueAndSortBySequenceCourses() {
        return repository.findAllByEnabledTrueOrderByNumberInSequenceAsc();
    }

    public List<Course> findAllAndSortBySequenceCourses() {
        return repository.findAllByOrderByNumberInSequenceAsc();
    }

    public Course findByIdAndSortBySequenceModulesAndLessons(Integer courseId) {
        Course course = findById(courseId);
        sortBySequenceModulesAndLessons(course);

        return course;
    }

    public Course findByIdAndEnabledTrueAndSortBySequenceModulesAndLessons(Integer courseId) {
        Course course = repository.findByIdAndEnabledTrue(courseId).orElseThrow(EntityNotFoundException::new);
        sortBySequenceModulesAndLessons(course);

        return course;
    }

    @Override
    public Course editById(Integer integer, Course edited) {
        Course course = findById(integer);
        if (!course.getNumberInSequence().equals(edited.getNumberInSequence())
                && repository.existsByNumberInSequence(edited.getNumberInSequence())) {
            throw new UniqueConstraintException(new ObjectError(objectName, "Указаный номер в последовательности уже существует"));
        }
        course.setTransportCategory(edited.getTransportCategory());
        course.setTitle(edited.getTitle());
        course.setDescription(edited.getDescription());
        course.setAllowedTo(edited.getAllowedTo());
        course.setCategoryTechnicalRegulations(edited.getCategoryTechnicalRegulations());
        course.setNumberInSequence(edited.getNumberInSequence());
        course.setEnabled(edited.getEnabled());
        return repository.save(course);
    }

    @Override
    public Course create(Course course) {
        if (repository.existsByNumberInSequence(course.getNumberInSequence())) {
            throw new UniqueConstraintException(new ObjectError(objectName, "Указаный номер в последовательности уже существует"));
        }
        return super.create(course);
    }

    public LessonNavigatorDto constructLessonNavigator(Integer courseId, Integer moduleId, Integer lessonId) {
        Course course = findByIdAndEnabledTrueAndSortBySequenceModulesAndLessons(courseId);

        LessonNavigatorDto lessonNavigator = new LessonNavigatorDto();
        lessonNavigator.setCourse(course);
        lessonNavigator.setModule(extractModule(course, moduleId));
        lessonNavigator.setLesson(extractLesson(course, moduleId, lessonId));
        lessonNavigator.setNextLesson(findNextLesson(course, moduleId, lessonId).orElse(null));
        lessonNavigator.setPreviousLesson(findPreviousLesson(course, moduleId, lessonId).orElse(null));

        return lessonNavigator;
    }

    private void sortBySequenceModulesAndLessons(Course course) {
        List<CourseModule> courseModules = course.getCourseModules();

        //sorting modules
        courseModules.sort(Comparator.comparingInt(CourseModule::getNumberInSequence));

        //sorting lessons in modules
        courseModules.forEach(courseModule -> {
            courseModule.getModule().getModuleLessons().sort(Comparator.comparingInt(ModuleLesson::getNumberInSequence));
        });
    }

    private Optional<Lesson> findNextLesson(Course courseSortedBySequence, Integer moduleId, Integer fromLessonId) {
        List<Lesson> lessons = extractLessons(courseSortedBySequence, moduleId);

        boolean searchedLessonFound = false;
        for (Lesson lesson : lessons) {
            if (searchedLessonFound) {
                return Optional.of(lesson);
            } else if (lesson.getId().equals(fromLessonId)) {
                searchedLessonFound = true;
            }
        }

        return Optional.empty();
    }

    private Optional<Lesson> findPreviousLesson(Course courseSortedBySequence, Integer moduleId, Integer fromLessonId) {
        List<Lesson> lessons = extractLessons(courseSortedBySequence, moduleId);

        Lesson previousLessonInLoop = null;
        for (Lesson lesson : lessons) {
            if (lesson.getId().equals(fromLessonId)) {
                if (previousLessonInLoop != null) {
                    return Optional.of(previousLessonInLoop);
                } else {
                    return Optional.empty();
                }
            }
            previousLessonInLoop = lesson;
        }

        return Optional.empty();
    }

    private Module extractModule(Course course, Integer moduleId) {
        return course.getCourseModules().stream()
                .map(CourseModule::getModule)
                .filter(module -> module.getId().equals(moduleId))
                .findFirst()
                .orElseThrow(EntityNotFoundException::new);
    }

    private Lesson extractLesson(Course course, Integer moduleId, Integer lessonId) {
        List<Lesson> lessons = extractLessons(course, moduleId);
        for (Lesson lesson : lessons) {
            if (lesson.getId().equals(lessonId)) {
                return lesson;
            }
        }

        throw new EntityNotFoundException();
    }

    private List<Lesson> extractLessons(Course course, Integer moduleId) {
        Module module = extractModule(course, moduleId);
        return module.getModuleLessons().stream()
                .map(ModuleLesson::getLesson).toList();
    }

    public void addModule(Integer id, CourseModule courseModule) {
        Course course = findById(id);
        if (hasModule(course, courseModule.getModule().getId())) {
            throw new UniqueConstraintException(new ObjectError(objectName, "Модуль уже был привязан ранее"));
        }
        if (hasNumberInSequenceByModules(course, courseModule.getNumberInSequence())) {
            throw new UniqueConstraintException(new ObjectError(objectName, "Указаный номер в последовательности уже существует"));
        }

        course.addCourseModule(courseModule);
        repository.save(course);
    }

    public void removeModule(Integer id, Integer moduleId) {
        Course course = findById(id);
        if (!hasModule(course, moduleId)) {
            throw new EntityBoundException(new ObjectError(objectName, "Указанный модуль не привязан"));
        }

        List<CourseModule> courseModules = course.getCourseModules();
        for (CourseModule courseModule : courseModules) {
            if (courseModule.getModule().getId().equals(moduleId)) {
                course.removeCourseModule(courseModule);
                repository.save(course);
                break;
            }
        }
    }

    private boolean hasModule(Course course, Integer moduleId) {
        return course.getCourseModules()
                .stream()
                .anyMatch(moduleLesson -> moduleLesson.getModule().getId().equals(moduleId));
    }

    private boolean hasNumberInSequenceByModules(Course course, Integer numberInSequence) {
        return course.getCourseModules()
                .stream()
                .anyMatch(courseModule -> courseModule.getNumberInSequence().equals(numberInSequence));
    }
}
