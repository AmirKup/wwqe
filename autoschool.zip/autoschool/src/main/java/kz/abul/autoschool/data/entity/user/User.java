package kz.abul.autoschool.data.entity.user;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import kz.abul.autoschool.data.entity.base.SerialPkEntity;
import kz.abul.autoschool.validation.CreateValidation;
import kz.abul.autoschool.validation.EditValidation;
import kz.abul.autoschool.validation.SaveValidation;
import lombok.Getter;
import lombok.Setter;

import java.util.*;

@Entity
@Table(name = "users", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
@Getter
@Setter
public class User extends SerialPkEntity<Integer> {

    @NotBlank(groups = {CreateValidation.class, SaveValidation.class}, message = "Поле \"Email\" не заполнено")
    @Email(groups = {CreateValidation.class, SaveValidation.class}, message = "Неккоректный \"Email\"")
    private String email;

    @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z0-9@#$%^&+=_]{7,25}$",
            groups = CreateValidation.class, message = "\"Пароль\" должен содержать буквы A-z, цифры 0-9, и по желанию спецсимволы @#$%^&+=")
    @NotBlank(groups = SaveValidation.class)
    private String password;

    @NotBlank(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Имя\" не заполнено")
    private String name;

    @NotBlank(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Фамилия\" не заполнено")
    private String surname;

    @NotBlank(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Отчество\" не заполнено")
    private String patronymic;

    @NotNull(groups = {CreateValidation.class, EditValidation.class, SaveValidation.class}, message = "Поле \"Пол\" не заполнено")
    @Enumerated(EnumType.ORDINAL)
    private Gender gender;

    @NotNull(groups = {CreateValidation.class, SaveValidation.class}, message = "Поле \"Я согласен с условиями сервиса\" не заполнено")
    @AssertTrue(groups = {CreateValidation.class, SaveValidation.class}, message = "Поле \"Я согласен с условиями сервиса\" должно быть отмечено")
    private Boolean termsAgreed;

    @NotNull(groups = {SaveValidation.class}, message = "Поле \"Заблокирован\" не заполнено")
    private Boolean locked;

    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.EAGER)
    @JoinTable(name = "users_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> roles = new HashSet<>();

    public void addRole(Role role){
        roles.add(role);
        role.getUsers().add(this);
    }

    public void removeRole(Role role){
        roles.remove(role);
        role.getUsers().remove(this);
    }
}