package kz.abul.autoschool.service.base;

import jakarta.persistence.EntityNotFoundException;
import kz.abul.autoschool.data.entity.base.SerialPkEntity;
import kz.abul.autoschool.data.entity.study.Module;
import kz.abul.autoschool.data.entity.study.mapping.ModuleLesson;
import kz.abul.autoschool.error.EntityDeleteException;
import kz.abul.autoschool.repository.ModuleRepository;
import kz.abul.autoschool.service.ModuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.validation.ObjectError;

import java.util.ArrayList;
import java.util.List;

@Service
public abstract class CrudSerialPkServiceImpl<T extends SerialPkEntity<ID>, ID extends Number, R extends JpaRepository<T, ID>> implements CrudSerialPkService<T, ID> {
    @Autowired
    protected R repository;

    @Override
    public Page<T> findAll(Pageable pageable) {
        return repository.findAll(pageable);
    }

    @Override
    public List<T> findAll() {
        return repository.findAll();
    }

    @Override
    public T findById(ID id) {
        return repository.findById(id)
                .orElseThrow(EntityNotFoundException::new);
    }

    @Override
    public T editById(ID id, T edited) {
        edited.setId(id);
        return repository.save(edited);
    }

    @Override
    public void deleteById(ID id) {
        repository.deleteById(id);
    }

    @Override
    public T create(T t) {
        t.setId(null);
        return repository.save(t);
    }
}
